使用说明：
1、本软件用于英文指法练习
2、可自行创建 E01.txt、E02.txt、E03.txt、E04.txt
3、许可协议：GPL
4、来自基础教程网：http://teliute.org