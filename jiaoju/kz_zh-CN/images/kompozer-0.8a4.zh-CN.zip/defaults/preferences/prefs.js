pref("general.useragent.locale","zh-CN");
