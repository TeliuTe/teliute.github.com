#!/bin/bash

#批量合并/7文件夹下的17个子文件夹里面的7.txt和7__.txt，每行后面加上<br />，用于复制到html文件里
for ((x=1; x <= 17; x++))
do
	cd $x

	#加在7__.txt的文件尾加两个换行符
	echo "<br /><br />" >> 7__.txt

	#加一个空行好看，/n，而不是/r/n 所以没法一下替换
	echo "" >>7__.txt

	#合并两个文件到新文件，提前在父目录建一个t文件夹存放合并后的文件
	cat 7__.txt 7.txt > ../t/$x.txt
	#mv $x.txt ../t
	cd ..
	

done

#用rpl 给每一行后面加上html换行符，先切换到子目录里
cd t

#行尾用的是windows格式
rpl -Rde '\r\n'  '<br />\r\n'  ./


