#!/bin/bash
mkdir /opt/lampp/htdocs/ftp/8-1a1	
mkdir /opt/lampp/htdocs/ftp/8-1a2	
mkdir /opt/lampp/htdocs/ftp/8-1a3	
mkdir /opt/lampp/htdocs/ftp/8-1a4	
mkdir /opt/lampp/htdocs/ftp/8-1a5	
mkdir /opt/lampp/htdocs/ftp/8-1a6	
mkdir /opt/lampp/htdocs/ftp/8-1a7	
mkdir /opt/lampp/htdocs/ftp/8-1a8	
mkdir /opt/lampp/htdocs/ftp/8-1b1	
mkdir /opt/lampp/htdocs/ftp/8-1b2	
mkdir /opt/lampp/htdocs/ftp/8-1b3	
mkdir /opt/lampp/htdocs/ftp/8-1b4	
mkdir /opt/lampp/htdocs/ftp/8-1b5	
mkdir /opt/lampp/htdocs/ftp/8-1b6	
mkdir /opt/lampp/htdocs/ftp/8-1b7	
mkdir /opt/lampp/htdocs/ftp/8-1b8	
mkdir /opt/lampp/htdocs/ftp/8-1b9	
mkdir /opt/lampp/htdocs/ftp/8-1b10	
mkdir /opt/lampp/htdocs/ftp/8-1c1	
mkdir /opt/lampp/htdocs/ftp/8-1c2	
mkdir /opt/lampp/htdocs/ftp/8-1c3	
mkdir /opt/lampp/htdocs/ftp/8-1c4	
mkdir /opt/lampp/htdocs/ftp/8-1c5	
mkdir /opt/lampp/htdocs/ftp/8-1c6	
mkdir /opt/lampp/htdocs/ftp/8-1c7	
mkdir /opt/lampp/htdocs/ftp/8-1c8	
mkdir /opt/lampp/htdocs/ftp/8-1c9	
mkdir /opt/lampp/htdocs/ftp/8-1c10	
mkdir /opt/lampp/htdocs/ftp/8-1d1	
mkdir /opt/lampp/htdocs/ftp/8-1d2	
mkdir /opt/lampp/htdocs/ftp/8-1d3	
mkdir /opt/lampp/htdocs/ftp/8-1d4	
mkdir /opt/lampp/htdocs/ftp/8-1d5	
mkdir /opt/lampp/htdocs/ftp/8-1d6	
mkdir /opt/lampp/htdocs/ftp/8-1d7	
mkdir /opt/lampp/htdocs/ftp/8-1d8	
mkdir /opt/lampp/htdocs/ftp/8-1d9	
mkdir /opt/lampp/htdocs/ftp/8-1d10	
mkdir /opt/lampp/htdocs/ftp/8-2a1	
mkdir /opt/lampp/htdocs/ftp/8-2a2	
mkdir /opt/lampp/htdocs/ftp/8-2a3	
mkdir /opt/lampp/htdocs/ftp/8-2a4	
mkdir /opt/lampp/htdocs/ftp/8-2a5	
mkdir /opt/lampp/htdocs/ftp/8-2a6	
mkdir /opt/lampp/htdocs/ftp/8-2a7	
mkdir /opt/lampp/htdocs/ftp/8-2a8	
mkdir /opt/lampp/htdocs/ftp/8-2b1	
mkdir /opt/lampp/htdocs/ftp/8-2b2	
mkdir /opt/lampp/htdocs/ftp/8-2b3	
mkdir /opt/lampp/htdocs/ftp/8-2b4	
mkdir /opt/lampp/htdocs/ftp/8-2b5	
mkdir /opt/lampp/htdocs/ftp/8-2b6	
mkdir /opt/lampp/htdocs/ftp/8-2b7	
mkdir /opt/lampp/htdocs/ftp/8-2b8	
mkdir /opt/lampp/htdocs/ftp/8-2b9	
mkdir /opt/lampp/htdocs/ftp/8-2b10	
mkdir /opt/lampp/htdocs/ftp/8-2c1	
mkdir /opt/lampp/htdocs/ftp/8-2c2	
mkdir /opt/lampp/htdocs/ftp/8-2c3	
mkdir /opt/lampp/htdocs/ftp/8-2c4	
mkdir /opt/lampp/htdocs/ftp/8-2c5	
mkdir /opt/lampp/htdocs/ftp/8-2c6	
mkdir /opt/lampp/htdocs/ftp/8-2c7	
mkdir /opt/lampp/htdocs/ftp/8-2c8	
mkdir /opt/lampp/htdocs/ftp/8-2c9	
mkdir /opt/lampp/htdocs/ftp/8-2c10	
mkdir /opt/lampp/htdocs/ftp/8-2d1	
mkdir /opt/lampp/htdocs/ftp/8-2d2	
mkdir /opt/lampp/htdocs/ftp/8-2d3	
mkdir /opt/lampp/htdocs/ftp/8-2d4	
mkdir /opt/lampp/htdocs/ftp/8-2d5	
mkdir /opt/lampp/htdocs/ftp/8-2d6	
mkdir /opt/lampp/htdocs/ftp/8-2d7	
mkdir /opt/lampp/htdocs/ftp/8-2d8	
mkdir /opt/lampp/htdocs/ftp/8-2d9	
mkdir /opt/lampp/htdocs/ftp/8-2d10	
mkdir /opt/lampp/htdocs/ftp/8-3a1	
mkdir /opt/lampp/htdocs/ftp/8-3a2	
mkdir /opt/lampp/htdocs/ftp/8-3a3	
mkdir /opt/lampp/htdocs/ftp/8-3a4	
mkdir /opt/lampp/htdocs/ftp/8-3a5	
mkdir /opt/lampp/htdocs/ftp/8-3a6	
mkdir /opt/lampp/htdocs/ftp/8-3a7	
mkdir /opt/lampp/htdocs/ftp/8-3a8	
mkdir /opt/lampp/htdocs/ftp/8-3b1	
mkdir /opt/lampp/htdocs/ftp/8-3b2	
mkdir /opt/lampp/htdocs/ftp/8-3b3	
mkdir /opt/lampp/htdocs/ftp/8-3b4	
mkdir /opt/lampp/htdocs/ftp/8-3b5	
mkdir /opt/lampp/htdocs/ftp/8-3b6	
mkdir /opt/lampp/htdocs/ftp/8-3b7	
mkdir /opt/lampp/htdocs/ftp/8-3b8	
mkdir /opt/lampp/htdocs/ftp/8-3b9	
mkdir /opt/lampp/htdocs/ftp/8-3b10	
mkdir /opt/lampp/htdocs/ftp/8-3c1	
mkdir /opt/lampp/htdocs/ftp/8-3c2	
mkdir /opt/lampp/htdocs/ftp/8-3c3	
mkdir /opt/lampp/htdocs/ftp/8-3c4	
mkdir /opt/lampp/htdocs/ftp/8-3c5	
mkdir /opt/lampp/htdocs/ftp/8-3c6	
mkdir /opt/lampp/htdocs/ftp/8-3c7	
mkdir /opt/lampp/htdocs/ftp/8-3c8	
mkdir /opt/lampp/htdocs/ftp/8-3c9	
mkdir /opt/lampp/htdocs/ftp/8-3c10	
mkdir /opt/lampp/htdocs/ftp/8-3d1	
mkdir /opt/lampp/htdocs/ftp/8-3d2	
mkdir /opt/lampp/htdocs/ftp/8-3d3	
mkdir /opt/lampp/htdocs/ftp/8-3d4	
mkdir /opt/lampp/htdocs/ftp/8-3d5	
mkdir /opt/lampp/htdocs/ftp/8-3d6	
mkdir /opt/lampp/htdocs/ftp/8-3d7	
mkdir /opt/lampp/htdocs/ftp/8-3d8	
mkdir /opt/lampp/htdocs/ftp/8-3d9	
mkdir /opt/lampp/htdocs/ftp/8-3d10	
mkdir /opt/lampp/htdocs/ftp/8-4a1	
mkdir /opt/lampp/htdocs/ftp/8-4a2	
mkdir /opt/lampp/htdocs/ftp/8-4a3	
mkdir /opt/lampp/htdocs/ftp/8-4a4	
mkdir /opt/lampp/htdocs/ftp/8-4a5	
mkdir /opt/lampp/htdocs/ftp/8-4a6	
mkdir /opt/lampp/htdocs/ftp/8-4a7	
mkdir /opt/lampp/htdocs/ftp/8-4a8	
mkdir /opt/lampp/htdocs/ftp/8-4b1	
mkdir /opt/lampp/htdocs/ftp/8-4b2	
mkdir /opt/lampp/htdocs/ftp/8-4b3	
mkdir /opt/lampp/htdocs/ftp/8-4b4	
mkdir /opt/lampp/htdocs/ftp/8-4b5	
mkdir /opt/lampp/htdocs/ftp/8-4b6	
mkdir /opt/lampp/htdocs/ftp/8-4b7	
mkdir /opt/lampp/htdocs/ftp/8-4b8	
mkdir /opt/lampp/htdocs/ftp/8-4b9	
mkdir /opt/lampp/htdocs/ftp/8-4b10	
mkdir /opt/lampp/htdocs/ftp/8-4c1	
mkdir /opt/lampp/htdocs/ftp/8-4c2	
mkdir /opt/lampp/htdocs/ftp/8-4c3	
mkdir /opt/lampp/htdocs/ftp/8-4c4	
mkdir /opt/lampp/htdocs/ftp/8-4c5	
mkdir /opt/lampp/htdocs/ftp/8-4c6	
mkdir /opt/lampp/htdocs/ftp/8-4c7	
mkdir /opt/lampp/htdocs/ftp/8-4c8	
mkdir /opt/lampp/htdocs/ftp/8-4c9	
mkdir /opt/lampp/htdocs/ftp/8-4c10	
mkdir /opt/lampp/htdocs/ftp/8-4d1	
mkdir /opt/lampp/htdocs/ftp/8-4d2	
mkdir /opt/lampp/htdocs/ftp/8-4d3	
mkdir /opt/lampp/htdocs/ftp/8-4d4	
mkdir /opt/lampp/htdocs/ftp/8-4d5	
mkdir /opt/lampp/htdocs/ftp/8-4d6	
mkdir /opt/lampp/htdocs/ftp/8-4d7	
mkdir /opt/lampp/htdocs/ftp/8-4d8	
mkdir /opt/lampp/htdocs/ftp/8-4d9	
mkdir /opt/lampp/htdocs/ftp/8-4d10	
chown -R	2001:2000	/opt/lampp/htdocs/ftp/8-1a1
chown -R	2002:2000	/opt/lampp/htdocs/ftp/8-1a2
chown -R	2003:2000	/opt/lampp/htdocs/ftp/8-1a3
chown -R	2004:2000	/opt/lampp/htdocs/ftp/8-1a4
chown -R	2005:2000	/opt/lampp/htdocs/ftp/8-1a5
chown -R	2006:2000	/opt/lampp/htdocs/ftp/8-1a6
chown -R	2007:2000	/opt/lampp/htdocs/ftp/8-1a7
chown -R	2008:2000	/opt/lampp/htdocs/ftp/8-1a8
chown -R	2009:2000	/opt/lampp/htdocs/ftp/8-1b1
chown -R	2010:2000	/opt/lampp/htdocs/ftp/8-1b2
chown -R	2011:2000	/opt/lampp/htdocs/ftp/8-1b3
chown -R	2012:2000	/opt/lampp/htdocs/ftp/8-1b4
chown -R	2013:2000	/opt/lampp/htdocs/ftp/8-1b5
chown -R	2014:2000	/opt/lampp/htdocs/ftp/8-1b6
chown -R	2015:2000	/opt/lampp/htdocs/ftp/8-1b7
chown -R	2016:2000	/opt/lampp/htdocs/ftp/8-1b8
chown -R	2017:2000	/opt/lampp/htdocs/ftp/8-1b9
chown -R	2018:2000	/opt/lampp/htdocs/ftp/8-1b10
chown -R	2019:2000	/opt/lampp/htdocs/ftp/8-1c1
chown -R	2020:2000	/opt/lampp/htdocs/ftp/8-1c2
chown -R	2021:2000	/opt/lampp/htdocs/ftp/8-1c3
chown -R	2022:2000	/opt/lampp/htdocs/ftp/8-1c4
chown -R	2023:2000	/opt/lampp/htdocs/ftp/8-1c5
chown -R	2024:2000	/opt/lampp/htdocs/ftp/8-1c6
chown -R	2025:2000	/opt/lampp/htdocs/ftp/8-1c7
chown -R	2026:2000	/opt/lampp/htdocs/ftp/8-1c8
chown -R	2027:2000	/opt/lampp/htdocs/ftp/8-1c9
chown -R	2028:2000	/opt/lampp/htdocs/ftp/8-1c10
chown -R	2029:2000	/opt/lampp/htdocs/ftp/8-1d1
chown -R	2030:2000	/opt/lampp/htdocs/ftp/8-1d2
chown -R	2031:2000	/opt/lampp/htdocs/ftp/8-1d3
chown -R	2032:2000	/opt/lampp/htdocs/ftp/8-1d4
chown -R	2033:2000	/opt/lampp/htdocs/ftp/8-1d5
chown -R	2034:2000	/opt/lampp/htdocs/ftp/8-1d6
chown -R	2035:2000	/opt/lampp/htdocs/ftp/8-1d7
chown -R	2036:2000	/opt/lampp/htdocs/ftp/8-1d8
chown -R	2037:2000	/opt/lampp/htdocs/ftp/8-1d9
chown -R	2038:2000	/opt/lampp/htdocs/ftp/8-1d10
chown -R	2039:2000	/opt/lampp/htdocs/ftp/8-2a1
chown -R	2040:2000	/opt/lampp/htdocs/ftp/8-2a2
chown -R	2041:2000	/opt/lampp/htdocs/ftp/8-2a3
chown -R	2042:2000	/opt/lampp/htdocs/ftp/8-2a4
chown -R	2043:2000	/opt/lampp/htdocs/ftp/8-2a5
chown -R	2044:2000	/opt/lampp/htdocs/ftp/8-2a6
chown -R	2045:2000	/opt/lampp/htdocs/ftp/8-2a7
chown -R	2046:2000	/opt/lampp/htdocs/ftp/8-2a8
chown -R	2047:2000	/opt/lampp/htdocs/ftp/8-2b1
chown -R	2048:2000	/opt/lampp/htdocs/ftp/8-2b2
chown -R	2049:2000	/opt/lampp/htdocs/ftp/8-2b3
chown -R	2050:2000	/opt/lampp/htdocs/ftp/8-2b4
chown -R	2051:2000	/opt/lampp/htdocs/ftp/8-2b5
chown -R	2052:2000	/opt/lampp/htdocs/ftp/8-2b6
chown -R	2053:2000	/opt/lampp/htdocs/ftp/8-2b7
chown -R	2054:2000	/opt/lampp/htdocs/ftp/8-2b8
chown -R	2055:2000	/opt/lampp/htdocs/ftp/8-2b9
chown -R	2056:2000	/opt/lampp/htdocs/ftp/8-2b10
chown -R	2057:2000	/opt/lampp/htdocs/ftp/8-2c1
chown -R	2058:2000	/opt/lampp/htdocs/ftp/8-2c2
chown -R	2059:2000	/opt/lampp/htdocs/ftp/8-2c3
chown -R	2060:2000	/opt/lampp/htdocs/ftp/8-2c4
chown -R	2061:2000	/opt/lampp/htdocs/ftp/8-2c5
chown -R	2062:2000	/opt/lampp/htdocs/ftp/8-2c6
chown -R	2063:2000	/opt/lampp/htdocs/ftp/8-2c7
chown -R	2064:2000	/opt/lampp/htdocs/ftp/8-2c8
chown -R	2065:2000	/opt/lampp/htdocs/ftp/8-2c9
chown -R	2066:2000	/opt/lampp/htdocs/ftp/8-2c10
chown -R	2067:2000	/opt/lampp/htdocs/ftp/8-2d1
chown -R	2068:2000	/opt/lampp/htdocs/ftp/8-2d2
chown -R	2069:2000	/opt/lampp/htdocs/ftp/8-2d3
chown -R	2070:2000	/opt/lampp/htdocs/ftp/8-2d4
chown -R	2071:2000	/opt/lampp/htdocs/ftp/8-2d5
chown -R	2072:2000	/opt/lampp/htdocs/ftp/8-2d6
chown -R	2073:2000	/opt/lampp/htdocs/ftp/8-2d7
chown -R	2074:2000	/opt/lampp/htdocs/ftp/8-2d8
chown -R	2075:2000	/opt/lampp/htdocs/ftp/8-2d9
chown -R	2076:2000	/opt/lampp/htdocs/ftp/8-2d10
chown -R	2077:2000	/opt/lampp/htdocs/ftp/8-3a1
chown -R	2078:2000	/opt/lampp/htdocs/ftp/8-3a2
chown -R	2079:2000	/opt/lampp/htdocs/ftp/8-3a3
chown -R	2080:2000	/opt/lampp/htdocs/ftp/8-3a4
chown -R	2081:2000	/opt/lampp/htdocs/ftp/8-3a5
chown -R	2082:2000	/opt/lampp/htdocs/ftp/8-3a6
chown -R	2083:2000	/opt/lampp/htdocs/ftp/8-3a7
chown -R	2084:2000	/opt/lampp/htdocs/ftp/8-3a8
chown -R	2085:2000	/opt/lampp/htdocs/ftp/8-3b1
chown -R	2086:2000	/opt/lampp/htdocs/ftp/8-3b2
chown -R	2087:2000	/opt/lampp/htdocs/ftp/8-3b3
chown -R	2088:2000	/opt/lampp/htdocs/ftp/8-3b4
chown -R	2089:2000	/opt/lampp/htdocs/ftp/8-3b5
chown -R	2090:2000	/opt/lampp/htdocs/ftp/8-3b6
chown -R	2091:2000	/opt/lampp/htdocs/ftp/8-3b7
chown -R	2092:2000	/opt/lampp/htdocs/ftp/8-3b8
chown -R	2093:2000	/opt/lampp/htdocs/ftp/8-3b9
chown -R	2094:2000	/opt/lampp/htdocs/ftp/8-3b10
chown -R	2095:2000	/opt/lampp/htdocs/ftp/8-3c1
chown -R	2096:2000	/opt/lampp/htdocs/ftp/8-3c2
chown -R	2097:2000	/opt/lampp/htdocs/ftp/8-3c3
chown -R	2098:2000	/opt/lampp/htdocs/ftp/8-3c4
chown -R	2099:2000	/opt/lampp/htdocs/ftp/8-3c5
chown -R	2100:2000	/opt/lampp/htdocs/ftp/8-3c6
chown -R	2101:2000	/opt/lampp/htdocs/ftp/8-3c7
chown -R	2102:2000	/opt/lampp/htdocs/ftp/8-3c8
chown -R	2103:2000	/opt/lampp/htdocs/ftp/8-3c9
chown -R	2104:2000	/opt/lampp/htdocs/ftp/8-3c10
chown -R	2105:2000	/opt/lampp/htdocs/ftp/8-3d1
chown -R	2106:2000	/opt/lampp/htdocs/ftp/8-3d2
chown -R	2107:2000	/opt/lampp/htdocs/ftp/8-3d3
chown -R	2108:2000	/opt/lampp/htdocs/ftp/8-3d4
chown -R	2109:2000	/opt/lampp/htdocs/ftp/8-3d5
chown -R	2110:2000	/opt/lampp/htdocs/ftp/8-3d6
chown -R	2111:2000	/opt/lampp/htdocs/ftp/8-3d7
chown -R	2112:2000	/opt/lampp/htdocs/ftp/8-3d8
chown -R	2113:2000	/opt/lampp/htdocs/ftp/8-3d9
chown -R	2114:2000	/opt/lampp/htdocs/ftp/8-3d10
chown -R	2115:2000	/opt/lampp/htdocs/ftp/8-4a1
chown -R	2116:2000	/opt/lampp/htdocs/ftp/8-4a2
chown -R	2117:2000	/opt/lampp/htdocs/ftp/8-4a3
chown -R	2118:2000	/opt/lampp/htdocs/ftp/8-4a4
chown -R	2119:2000	/opt/lampp/htdocs/ftp/8-4a5
chown -R	2120:2000	/opt/lampp/htdocs/ftp/8-4a6
chown -R	2121:2000	/opt/lampp/htdocs/ftp/8-4a7
chown -R	2122:2000	/opt/lampp/htdocs/ftp/8-4a8
chown -R	2123:2000	/opt/lampp/htdocs/ftp/8-4b1
chown -R	2124:2000	/opt/lampp/htdocs/ftp/8-4b2
chown -R	2125:2000	/opt/lampp/htdocs/ftp/8-4b3
chown -R	2126:2000	/opt/lampp/htdocs/ftp/8-4b4
chown -R	2127:2000	/opt/lampp/htdocs/ftp/8-4b5
chown -R	2128:2000	/opt/lampp/htdocs/ftp/8-4b6
chown -R	2129:2000	/opt/lampp/htdocs/ftp/8-4b7
chown -R	2130:2000	/opt/lampp/htdocs/ftp/8-4b8
chown -R	2131:2000	/opt/lampp/htdocs/ftp/8-4b9
chown -R	2132:2000	/opt/lampp/htdocs/ftp/8-4b10
chown -R	2133:2000	/opt/lampp/htdocs/ftp/8-4c1
chown -R	2134:2000	/opt/lampp/htdocs/ftp/8-4c2
chown -R	2135:2000	/opt/lampp/htdocs/ftp/8-4c3
chown -R	2136:2000	/opt/lampp/htdocs/ftp/8-4c4
chown -R	2137:2000	/opt/lampp/htdocs/ftp/8-4c5
chown -R	2138:2000	/opt/lampp/htdocs/ftp/8-4c6
chown -R	2139:2000	/opt/lampp/htdocs/ftp/8-4c7
chown -R	2140:2000	/opt/lampp/htdocs/ftp/8-4c8
chown -R	2141:2000	/opt/lampp/htdocs/ftp/8-4c9
chown -R	2142:2000	/opt/lampp/htdocs/ftp/8-4c10
chown -R	2143:2000	/opt/lampp/htdocs/ftp/8-4d1
chown -R	2144:2000	/opt/lampp/htdocs/ftp/8-4d2
chown -R	2145:2000	/opt/lampp/htdocs/ftp/8-4d3
chown -R	2146:2000	/opt/lampp/htdocs/ftp/8-4d4
chown -R	2147:2000	/opt/lampp/htdocs/ftp/8-4d5
chown -R	2148:2000	/opt/lampp/htdocs/ftp/8-4d6
chown -R	2149:2000	/opt/lampp/htdocs/ftp/8-4d7
chown -R	2150:2000	/opt/lampp/htdocs/ftp/8-4d8
chown -R	2151:2000	/opt/lampp/htdocs/ftp/8-4d9
chown -R	2152:2000	/opt/lampp/htdocs/ftp/8-4d10
