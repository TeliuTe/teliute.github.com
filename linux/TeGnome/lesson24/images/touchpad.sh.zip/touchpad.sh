#!/bin/sh
if xinput list-props "SynPS/2 Synaptics TouchPad" | grep "Device Enabled" | grep 1
then
modprobe -r psmouse
else
modprobe psmouse
fi
# 开关触摸板
